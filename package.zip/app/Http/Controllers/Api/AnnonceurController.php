<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Annonceur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AnnonceurController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
       
        return response()->json(Annonceur::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $formfield=$request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:Annonceurs,email',
            'password' => 'required|string|min:6',
            'tel' => 'required|string|max:20',
       ]);

       $formfield['password']=Hash::make($formfield['password']);
       $new_annonceur=Annonceur::create($formfield);
       return response()->json($new_annonceur);
    }

    /**
     * Display the specified resource.
     */
    public function show(Annonceur $annonceur)
    {
        return response()->json($annonceur);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Annonceur $annonceur)
    {
        $formfield = request()->all();

        if(isset($formfield['password']))
          $formfield['password']=Hash::make($formfield['password']);

        $annonceur->update($formfield);

      return response()->json($annonceur);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Annonceur $annonceur)
    {

        config(['auth.guards.api.provider' => 'administrateurs']);
        if (Auth::guard('api')->check() && Auth::guard('api')->user()) {
            $annonceur->delete();
            return response()->json(['message' => 'Annonceur supprimé avec succès']);
        }

        return response()->json(['message' => 'Vous n\'avez pas les autorisations nécessaires pour effectuer cette action'], 403);


    }
}
