<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Responsable_Universitaire;
use Illuminate\Contracts\Auth\Guard;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ResponsableuniversitaireController extends Controller
{
     /**
     * Display a listing of the resource.
     */
    public function index()
    {
        config(['auth.guards.api.provider' => 'administrateurs']);

         /* if(!Auth::guard('api')->user()){
            return response()->json(['error' => 'Unauthorized'], 401);
          }*/

          return Auth::guard('api')->user();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {


        $formfield=$request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:responsable_universitaires,email',
            'password' => 'required|string|min:6',
            'tel' => 'required|string|max:20',
            'nom_Organization'=>'required|string',
       ]);

       $formfield['password']=Hash::make($formfield['password']);
       $new_responsable=Responsable_Universitaire::create($formfield);

       return response()->json($new_responsable);
    }

    /**
     * Display the specified resource.
     */
    public function show(Responsable_Universitaire $responsable_universitaire)
    {
        config(['auth.guards.api.provider' => 'administrateurs']);
        if(Auth::guard('api')->check() && Auth::guard('api')->user())
            return  response()->json($responsable_universitaire);

        config(['auth.guards.api.provider' => 'responsable_universitaires']);
        if(Auth::guard('api')->check() && Auth::guard('api')->user()->id === Auth::guard('responsable_universitaires')->user()->id)
            return  response()->json($responsable_universitaire);

        return response()->json(['error' => 'Unauthorized'], 401);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Responsable_Universitaire $responsable_universitaire)
    {


        $formfield = request()->all();

        if(isset($formfield['password']))
          $formfield['password']=Hash::make($formfield['password']);


         config(['auth.guards.api.provider' => 'administrateurs']);
          if (Auth::guard('api')->check() && Auth::guard('api')->user()) {
              $responsable_universitaire->update($formfield);
              return response()->json($responsable_universitaire);
          }

          config(['auth.guards.api.provider' => 'responsable_universitaires']);
          if (Auth::guard('api')->check() && Auth::guard('api')->user()->id === $responsable_universitaire->id) {
              $responsable_universitaire->update($formfield);
              return response()->json($responsable_universitaire);
          }

    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Responsable_Universitaire $responsable_universitaire)
    {
        config(['auth.guards.api.provider' => 'administrateurs']);
        if (Auth::guard('api')->check() && Auth::guard('api')->user()) {
            $responsable_universitaire->delete();
            return response()->json(['message' => 'Responsable_Universitaire supprimé avec succès']);
        }

        return response()->json(['message' => 'Vous n\'avez pas les autorisations nécessaires pour effectuer cette action'], 403);

    }
}
