<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Administrateur;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class AdministrateurController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        return response()->json(Administrateur::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {

        $formfield=$request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:administrateurs,email',
            'password' => 'required|string|min:6',
            'tel' => 'required|string|max:20',
       ]);

       $formfield['password']=Hash::make($formfield['password']);
       $new_admin=Administrateur::create($formfield);
       return response()->json($new_admin);
    }

    /**
     * Display the specified resource.
     */
    public function show(Administrateur $administrateur)
    {
        return response()->json($administrateur);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Administrateur $administrateur)
    {
    
        $formfield = request()->all();

        if(isset($formfield['password']))
          $formfield['password']=Hash::make($formfield['password']);

        $administrateur->update($formfield);

      return response()->json($administrateur);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Administrateur $administrateur)
    {
        config(['auth.guards.api.provider' => 'administrateurs']);
        if (Auth::guard('api')->check() && Auth::guard('api')->user()) {
            $administrateur->delete();
            return response()->json(['message' => 'Administrateur supprimé avec succès']);
        }

        return response()->json(['message' => 'Vous n\'avez pas les autorisations nécessaires pour effectuer cette action'], 403);



    }
}
