<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Manager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class ManagerController extends Controller
{
    public function index()
    {
        
        return response()->json(Manager::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        config(['auth.guards.api.provider' => 'administrateurs']);

          if(!Auth::guard('api')->user()){
            return response()->json(['error' => 'Unauthorized'], 401);
          }

        config(['auth.guards.api.provider' => 'administrateurs']);

        if(!Auth::guard('api')->user()){
          return response()->json(['error' => 'Unauthorized'], 401);
        }

        $formfield=$request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:Managers,email',
            'password' => 'required|string|min:6',
            'tel' => 'required|string|max:20',
       ]);

       $formfield['password']=Hash::make($formfield['password']);
       $new_Manager=Manager::create($formfield);

       return response()->json($new_Manager);
    }

    /**
     * Display the specified resource.
     */
    public function show(Manager $manager)
    {
        return response()->json($manager);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Manager $manager)
    {
        config(['auth.guards.api.provider' => 'administrateurs']);

          if(!Auth::guard('api')->user()){
            return response()->json(['error' => 'Unauthorized'], 401);
          }
        $formfield = request()->all();

        if(isset($formfield['password']))
          $formfield['password']=Hash::make($formfield['password']);

        $manager->update($formfield);

      return response()->json($manager);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Manager $manager)
    {

        config(['auth.guards.api.provider' => 'administrateurs']);
        if (Auth::guard('api')->check() && Auth::guard('api')->user()) {
            $manager->delete();
            return response()->json(['message' => 'Manager supprimé avec succès']);
        }

        return response()->json(['message' => 'Vous n\'avez pas les autorisations nécessaires pour effectuer cette action'], 403);
    }
}
