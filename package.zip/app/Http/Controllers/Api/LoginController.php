<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class LoginController extends Controller
{
    public function login(Request $request)
    {
        $credentials = request(['email', 'password']);
        $role=$request->role;


        if (!Auth::guard($role)->attempt($credentials)) {
            return response()->json(['message' => 'Unauthorized'], 401);
        }

        $user = Auth::guard($role)->user();
        $token = $user->createToken($role.'_token')->accessToken;

        return response()->json([
            'user' => $user,
            'access_token' => $token
        ], 200);

    }
}
