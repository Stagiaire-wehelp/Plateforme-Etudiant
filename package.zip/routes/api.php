<?php

use App\Http\Controllers\Api\AdministrateurController;
use App\Http\Controllers\Api\AnnonceurController;
use App\Http\Controllers\Api\EtudiantController;
use App\Http\Controllers\Api\LoginController;
use App\Http\Controllers\Api\ManagerController;
use App\Http\Controllers\Api\ResponsableuniversitaireController;
use App\Models\Administrateur;
use App\Models\Annonceur;
use App\Models\Etudiant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login',[LoginController::class, 'login']);

Route::apiResource('administrateurs',AdministrateurController::class);

Route::apiResource('managers',ManagerController::class);

Route::apiResource('etudiants',EtudiantController::class);

Route::apiResource('annonceurs',AnnonceurController::class);

Route::apiResource('responsable_universitaires',ResponsableuniversitaireController::class);
